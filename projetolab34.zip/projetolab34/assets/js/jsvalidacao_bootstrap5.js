/*!
 * JavaScript Validação Bootstrap 5 Plugin v1.0.0
 *
 *
 * Copyright (c) 2021 Andreney Laranjeira
 * Released under the MIT license
 */

function vazio(input){
	var campo = document.getElementById(input);
	var valor_campo = campo.value;
	if(valor_campo == "" || valor_campo == null){
		campo.classList.add("is-invalid");
		campo.focus();
		return false;
	}else{
		campo.classList.remove("is-invalid");
		campo.classList.add("is-valid");
		return true
	}
}

function vtamanho(input, tamanho){
	var min = tamanho;
	var campo = document.getElementById(input);
	var valor_campo = campo.value;
	if(valor_campo.length < min || valor_campo == "" || valor_campo == null){
		campo.classList.add("is-invalid");
		campo.focus();
		return false;
	}else{
		campo.classList.remove("is-invalid");
		campo.classList.add("is-valid");
		return true
	}
}

function email(input){
	var campo = document.getElementById(input);
	var valor_campo = campo.value;
	if(!checar_email_valido(valor_campo)){
		campo.classList.add("is-invalid");
		campo.focus();
		return false;
	}else{
		campo.classList.remove("is-invalid");
		campo.classList.add("is-valid");
		return true
	}
}
function checar_email_valido(email) {
	var padrao = new RegExp(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]+$/);
	return padrao.test(email);
}

function radio(input){
	var campo = document.getElementsByName(input);
	var aux = 0;
	for (var i = 0; i < campo.length; i++) {
		if (campo[i].checked) {
			aux++;
		}
	}
	if(aux == 0){
		for (var i = 0; i < campo.length; i++) {
			campo[i].classList.add("is-invalid");
		}
		return false
	}else{
		for (var i = 0; i < campo.length; i++) {
			campo[i].classList.remove("is-invalid");
			campo[i].classList.add("is-valid");
		}
		return true
	}
}

function cpf(input){
	var campo = document.getElementById(input);
	var valor_campo = campo.value;
	exp = /\.|\-/g;
	strCPF = valor_campo.toString().replace( exp, "" );
	var Soma;
	var Resto;
	Soma = 0;
	if (strCPF.length != 11 || 
	strCPF == "00000000000" || 
	strCPF == "11111111111" || 
	strCPF == "22222222222" || 
	strCPF == "33333333333" || 
	strCPF == "44444444444" || 
	strCPF == "55555555555" || 
	strCPF == "66666666666" || 
	strCPF == "77777777777" || 
	strCPF == "88888888888" || 
	strCPF == "99999999999"){
		campo.classList.add("is-invalid");
		campo.focus();
		return false;
	}
	for (i=1; i<=9; i++) Soma = Soma + parseInt(strCPF.substring(i-1, i)) * (11 - i);
	Resto = (Soma * 10) % 11;

		if ((Resto == 10) || (Resto == 11))  Resto = 0;
		if (Resto != parseInt(strCPF.substring(9, 10)) ){
			campo.classList.add("is-invalid");
			return false;
		}
	Soma = 0;
		for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i-1, i)) * (12 - i);
		Resto = (Soma * 10) % 11;

		if ((Resto == 10) || (Resto == 11))  Resto = 0;
		if (Resto != parseInt(strCPF.substring(10, 11) ) ){
			campo.classList.add("is-invalid");
			return false;
		}
		campo.classList.remove("is-invalid");
		campo.classList.add("is-valid");
		$('#erro_cpf').html("");
		return true;
}

function vcnpj(input){
	var campo = document.getElementById(input);
	var valor_campo = campo.value;
	var exp = /[^\d]+/g;
	var strCNPJ = valor_campo.toString().replace( exp, "" );
	
	
	if(strCNPJ == ''){
		campo.classList.add("is-invalid");
		return false;
	}
	 
	if (strCNPJ.length < 14){
		campo.classList.add("is-invalid");
		return false;
	}
 
	// Elimina CNPJs invalidos conhecidos
	if (strCNPJ == "00000000000000" || 
		strCNPJ == "11111111111111" || 
		strCNPJ == "22222222222222" || 
		strCNPJ == "33333333333333" || 
		strCNPJ == "44444444444444" || 
		strCNPJ == "55555555555555" || 
		strCNPJ == "66666666666666" || 
		strCNPJ == "77777777777777" || 
		strCNPJ == "88888888888888" || 
		strCNPJ == "99999999999999"){
			campo.classList.add("is-invalid");
			return false;
		}
		 
	// Valida DVs
	tamanho = strCNPJ.length - 2
	numeros = strCNPJ.substring(0,tamanho);
	digitos = strCNPJ.substring(tamanho);
	soma = 0;
	pos = tamanho - 7;
	for (i = tamanho; i >= 1; i--) {
	  soma += numeros.charAt(tamanho - i) * pos--;
	  if (pos < 2)
			pos = 9;
	}
	resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
	if (resultado != digitos.charAt(0)){
		campo.classList.add("is-invalid");
		return false;
	}
		 
	tamanho = tamanho + 1;
	numeros = strCNPJ.substring(0,tamanho);
	soma = 0;
	pos = tamanho - 7;
	for (i = tamanho; i >= 1; i--) {
	  soma += numeros.charAt(tamanho - i) * pos--;
	  if (pos < 2)
			pos = 9;
	}
	resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
	if (resultado != digitos.charAt(1)){
		campo.classList.add("is-invalid");
		return false;
	}
	campo.classList.remove("is-invalid");
	campo.classList.add("is-valid");
	return true;
}